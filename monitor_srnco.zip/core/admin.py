from django.contrib import admin

# Register your models here.

# Este app não possui modelos próprios que precisem ser registrados no admin.
# O app 'core' funciona principalmente como app principal do projeto,
# contendo views e URLs gerais.